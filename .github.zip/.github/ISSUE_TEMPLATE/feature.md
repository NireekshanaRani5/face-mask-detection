---
name: 🚀 Feature
about: Submit a proposal for a new feature
labels: "feature"
---

## 🚀 Feature

(A clear and concise description of what the feature is.)

## Motivation

(Please outline the motivation for the proposal.)

## Pitch

(Please explain why this feature should be implemented and how it would be used.)
