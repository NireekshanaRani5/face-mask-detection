---
name: 💥 Proposal
about: Propose a non-trivial change to Face-Mask-detection
labels: "proposal"
---

## 💥 Proposal

(A clear and concise description of what the proposal is.)

